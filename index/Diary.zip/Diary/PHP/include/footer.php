<footer class="footer">
    <div class="footer_inner">
        <div>
            <img src="../../assets/img/footer__logo.png" alt="푸터 로고">
            <p>CODING CODI ALL Rrights Reserved</p>
            <p>Contact : to_before@naver.com</p>
        </div>
        <!-- <button>사이트맵</button> -->
    </div>
</footer>